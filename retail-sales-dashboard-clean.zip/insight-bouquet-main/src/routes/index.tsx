import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ArrowUpRight,
  BadgeDollarSign,
  Boxes,
  ReceiptText,
  Sparkles,
  TrendingUp,
  Users,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  applyFilters,
  categories,
  compact,
  groupBy,
  kpis,
  matrix,
  money,
  monthlyTrend,
  regions,
  salesData,
  type Filters,
} from "@/lib/sales";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Retail Sales Dashboard | Revenue, Profit & Regional Performance" },
      {
        name: "description",
        content:
          "Interactive retail sales dashboard covering revenue, profit, customers, categories and regional performance across 2025 orders.",
      },
      { property: "og:title", content: "Retail Sales Dashboard" },
      {
        property: "og:description",
        content:
          "Revenue, profit, customer and regional analytics rebuilt from the retail sales report.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const CHART = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

const axis = {
  stroke: "var(--muted-foreground)",
  fontSize: 11,
  tickLine: false,
  axisLine: false,
};

const tooltipStyle = {
  contentStyle: {
    background: "var(--popover)",
    border: "1px solid var(--border)",
    borderRadius: "0.85rem",
    color: "var(--popover-foreground)",
    fontSize: "12px",
    boxShadow: "var(--shadow-elegant)",
  },
  cursor: { fill: "var(--muted)", opacity: 0.35 },
};

function Kpi({
  label,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ElementType;
  accent: string;
}) {
  return (
    <Card className="glass-panel group relative overflow-hidden border-0 transition-transform duration-300 hover:-translate-y-1">
      <div
        className="pointer-events-none absolute -right-10 -top-12 size-32 rounded-full opacity-25 blur-2xl transition-opacity group-hover:opacity-45"
        style={{ background: accent }}
      />
      <CardContent className="relative flex items-start justify-between gap-4 pt-6">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
            {label}
          </p>
          <p className="font-display mt-2 text-3xl font-semibold tracking-tight text-foreground">
            {value}
          </p>
          {sub ? <p className="mt-1 text-xs text-muted-foreground">{sub}</p> : null}
        </div>
        <span
          className="rounded-2xl p-2.5 text-primary-foreground shadow-[var(--shadow-glow)]"
          style={{ background: accent }}
        >
          <Icon className="size-5" />
        </span>
      </CardContent>
    </Card>
  );
}

function Panel({
  title,
  action,
  className,
  bodyClass,
  children,
}: {
  title: string;
  action?: string | undefined;
  className?: string | undefined;
  bodyClass?: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <Card className={cn("glass-panel border-0", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="font-display text-sm font-semibold text-foreground">{title}</CardTitle>
        {action ? (
          <span className="rounded-full bg-secondary px-2.5 py-1 text-[10px] uppercase tracking-widest text-muted-foreground">
            {action}
          </span>
        ) : null}
      </CardHeader>
      <CardContent className={cn("h-[280px] pt-2", bodyClass)}>{children}</CardContent>
    </Card>
  );
}

function BarPanel({
  title,
  data,
  currency = true,
  color = "var(--chart-1)",
}: {
  title: string;
  data: { name: string; value: number }[];
  currency?: boolean;
  color?: string;
}) {
  const rotate = data.length > 5 || data.some((d) => d.name.length > 10);
  return (
    <Panel title={title}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ left: 8, right: 16, top: 8, bottom: rotate ? 28 : 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis
            dataKey="name"
            interval={0}
            angle={rotate ? -30 : 0}
            textAnchor={rotate ? "end" : "middle"}
            height={rotate ? 56 : 30}
            {...axis}
          />
          <YAxis {...axis} tickFormatter={(v: number) => compact(v)} />
          <Tooltip
            {...tooltipStyle}
            formatter={(v: number) => [currency ? money(v) : v.toLocaleString(), title]}
          />
          <Bar dataKey="value" radius={[8, 8, 4, 4]} fill={color} maxBarSize={46} />
        </BarChart>
      </ResponsiveContainer>
    </Panel>
  );
}

function DonutPanel({ title, data }: { title: string; data: { name: string; value: number }[] }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <Panel title={title}>
      <div className="relative h-full">
        <div className="pointer-events-none absolute inset-x-0 top-[38%] -translate-y-1/2 text-center">
          <p className="font-display text-xl font-semibold text-foreground">{money(total)}</p>
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Total</p>
        </div>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius="58%"
              outerRadius="82%"
              paddingAngle={3}
              cy="38%"
              stroke="none"
            >
              {data.map((_, i) => (
                <Cell key={i} fill={CHART[i % CHART.length]} />
              ))}
            </Pie>
            <Legend
              verticalAlign="bottom"
              iconType="circle"
              wrapperStyle={{ fontSize: 11, color: "var(--muted-foreground)" }}
            />
            <Tooltip {...tooltipStyle} formatter={(v: number) => money(v)} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </Panel>
  );
}

function RankPanel({
  title,
  data,
  currency = true,
  action,
}: {
  title: string;
  data: { name: string; value: number }[];
  currency?: boolean;
  action?: string | undefined;
}) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <Panel title={title} action={action} bodyClass="h-[280px] overflow-y-auto pt-2">
      <ol className="space-y-2.5">
        {data.map((d, i) => (
          <li key={d.name} className="group">
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="flex items-center gap-2 truncate text-foreground">
                <span className="w-4 text-[10px] tabular-nums text-muted-foreground">{i + 1}</span>
                <span className="truncate font-medium">{d.name}</span>
              </span>
              <span className="tabular-nums text-muted-foreground">
                {currency ? money(d.value) : d.value.toLocaleString()}
              </span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${(d.value / max) * 100}%`,
                  background: "var(--gradient-primary)",
                }}
              />
            </div>
          </li>
        ))}
      </ol>
    </Panel>
  );
}

function Dashboard() {
  const [filters, setFilters] = useState<Filters>({
    region: "all",
    category: "all",
    months: "all",
  });

  const rows = useMemo(() => applyFilters(salesData, filters), [filters]);
  const k = useMemo(() => kpis(rows), [rows]);
  const trend = useMemo(() => monthlyTrend(rows), [rows]);
  const byCategory = useMemo(() => groupBy(rows, "category", "sales"), [rows]);
  const profitByCategory = useMemo(() => groupBy(rows, "category", "profit"), [rows]);
  const byProduct = useMemo(() => groupBy(rows, "product", "sales").slice(0, 8), [rows]);
  const byRegion = useMemo(() => groupBy(rows, "region", "sales"), [rows]);
  const profitByRegion = useMemo(() => groupBy(rows, "region", "profit"), [rows]);
  const ordersByRegion = useMemo(() => groupBy(rows, "region", "orders"), [rows]);
  const topCustomers = useMemo(() => groupBy(rows, "customer", "sales").slice(0, 10), [rows]);
  const unitsByCategory = useMemo(() => groupBy(rows, "category", "quantity"), [rows]);
  const grid = useMemo(() => matrix(rows), [rows]);
  const maxCell = useMemo(
    () =>
      Math.max(
        1,
        ...grid.regionNames.flatMap((r) => grid.catNames.map((c) => grid.get(r, c))),
      ),
    [grid],
  );

  const regionShare = useMemo(() => {
    const total = byRegion.reduce((s, d) => s + d.value, 0) || 1;
    return byRegion.map((d, i) => ({
      name: d.name,
      value: Math.round((d.value / total) * 100),
      fill: CHART[i % CHART.length] ?? "var(--chart-1)",
    }));
  }, [byRegion]);

  const period =
    rows.length > 0 ? `${rows[0]!.date} → ${rows[rows.length - 1]!.date}` : "No matching orders";

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-border/60 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 sm:px-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <span
              className="rounded-2xl p-2 text-primary-foreground shadow-[var(--shadow-glow)]"
              style={{ background: "var(--gradient-primary)" }}
            >
              <BadgeDollarSign className="size-5" />
            </span>
            <div>
              <h1 className="font-display text-lg font-semibold tracking-tight">
                <span className="gradient-text">Retail Sales</span> Intelligence
              </h1>
              <p className="text-[11px] text-muted-foreground">{period}</p>
            </div>
            <Badge variant="secondary" className="hidden rounded-full sm:inline-flex">
              {rows.length} orders
            </Badge>
          </div>

          <div className="flex flex-wrap gap-2">
            <Select
              value={filters.region}
              onValueChange={(region) => setFilters((f) => ({ ...f, region }))}
            >
              <SelectTrigger className="w-[150px] rounded-full border-border/70 bg-card/60">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All regions</SelectItem>
                {regions.map((r) => (
                  <SelectItem key={r} value={r}>
                    {r}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={filters.category}
              onValueChange={(category) => setFilters((f) => ({ ...f, category }))}
            >
              <SelectTrigger className="w-[170px] rounded-full border-border/70 bg-card/60">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={String(filters.months)}
              onValueChange={(v) =>
                setFilters((f) => ({ ...f, months: v === "all" ? "all" : Number(v) }))
              }
            >
              <SelectTrigger className="w-[150px] rounded-full border-border/70 bg-card/60">
                <SelectValue placeholder="Period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Full year</SelectItem>
                <SelectItem value="6">Last 6 months</SelectItem>
                <SelectItem value="3">Last 3 months</SelectItem>
                <SelectItem value="1">Last month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <Kpi
            label="Total Sales"
            value={money(k.totalSales)}
            icon={BadgeDollarSign}
            accent="var(--gradient-primary)"
          />
          <Kpi
            label="Total Profit"
            value={money(k.totalProfit)}
            sub={`${k.margin.toFixed(1)}% margin`}
            icon={TrendingUp}
            accent="linear-gradient(135deg, var(--chart-5), var(--chart-2))"
          />
          <Kpi
            label="Total Orders"
            value={k.totalOrders.toLocaleString()}
            icon={ReceiptText}
            accent="linear-gradient(135deg, var(--chart-3), var(--chart-4))"
          />
          <Kpi
            label="Avg Order Value"
            value={money(k.avgOrderValue)}
            icon={ArrowUpRight}
            accent="linear-gradient(135deg, var(--chart-2), var(--chart-1))"
          />
          <Kpi
            label="Customers"
            value={k.totalCustomers.toLocaleString()}
            sub={`${k.units.toLocaleString()} units sold`}
            icon={Users}
            accent="linear-gradient(135deg, var(--chart-4), var(--chart-1))"
          />
        </div>

        <Tabs defaultValue="executive" className="mt-6">
          <TabsList className="flex-wrap rounded-full bg-card/60 p-1 backdrop-blur">
            <TabsTrigger value="executive" className="rounded-full">
              Executive Summary
            </TabsTrigger>
            <TabsTrigger value="sales" className="rounded-full">
              Sales Analysis
            </TabsTrigger>
            <TabsTrigger value="customers" className="rounded-full">
              Customer Analytics
            </TabsTrigger>
            <TabsTrigger value="regional" className="rounded-full">
              Regional Performance
            </TabsTrigger>
          </TabsList>

          <TabsContent value="executive" className="mt-4 space-y-4">
            <div className="grid gap-4 lg:grid-cols-3">
              <Panel
                title="Sales & profit momentum"
                action="Monthly"
                className="lg:col-span-2"
                bodyClass="h-[320px] pt-2"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trend} margin={{ left: 8, right: 16, top: 8, bottom: 8 }}>
                    <defs>
                      <linearGradient id="gSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.55} />
                        <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                      </linearGradient>
                      <linearGradient id="gProfit" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--chart-2)" stopOpacity={0.5} />
                        <stop offset="100%" stopColor="var(--chart-2)" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                    <XAxis dataKey="month" {...axis} />
                    <YAxis {...axis} tickFormatter={(v: number) => compact(v)} />
                    <Tooltip {...tooltipStyle} formatter={(v: number) => money(v)} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Area
                      type="monotone"
                      dataKey="sales"
                      name="Sales"
                      stroke="var(--chart-1)"
                      strokeWidth={2.5}
                      fill="url(#gSales)"
                    />
                    <Area
                      type="monotone"
                      dataKey="profit"
                      name="Profit"
                      stroke="var(--chart-2)"
                      strokeWidth={2.5}
                      fill="url(#gProfit)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </Panel>

              <Panel title="Region share of sales" action="%" bodyClass="h-[320px] pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <RadialBarChart
                    data={regionShare}
                    innerRadius="30%"
                    outerRadius="100%"
                    startAngle={90}
                    endAngle={-270}
                  >
                    <RadialBar dataKey="value" cornerRadius={10} background={{ fill: "var(--muted)" }} />
                    <Legend
                      iconType="circle"
                      verticalAlign="bottom"
                      wrapperStyle={{ fontSize: 11, color: "var(--muted-foreground)" }}
                      payload={regionShare.map((d) => ({
                        value: `${d.name} ${d.value}%`,
                        type: "circle",
                        color: d.fill,
                        id: d.name,
                      }))}
                    />
                    <Tooltip {...tooltipStyle} formatter={(v: number) => `${v}%`} />
                  </RadialBarChart>
                </ResponsiveContainer>
              </Panel>
            </div>
            <div className="grid gap-4 lg:grid-cols-2">
              <BarPanel title="Sales by category" data={byCategory} />
              <DonutPanel title="Profit by region" data={profitByRegion} />
            </div>
          </TabsContent>

          <TabsContent value="sales" className="mt-4 space-y-4">
            <div className="grid gap-4 lg:grid-cols-2">
              <BarPanel title="Sales by category" data={byCategory} />
              <DonutPanel title="Profit by category" data={profitByCategory} />
              <RankPanel title="Top products by sales" data={byProduct} action="Top 8" />
              <BarPanel title="Sales by region" data={byRegion} color="var(--chart-2)" />
            </div>
          </TabsContent>

          <TabsContent value="customers" className="mt-4 space-y-4">
            <div className="grid gap-4 lg:grid-cols-2">
              <RankPanel title="Top customers by sales" data={topCustomers} action="Top 10" />
              <BarPanel
                title="Units sold by category"
                data={unitsByCategory}
                currency={false}
                color="var(--chart-3)"
              />
              <BarPanel
                title="Orders by region"
                data={ordersByRegion}
                currency={false}
                color="var(--chart-5)"
              />
              <DonutPanel title="Profit by region" data={profitByRegion} />
            </div>
          </TabsContent>

          <TabsContent value="regional" className="mt-4 space-y-4">
            <div className="grid gap-4 lg:grid-cols-2">
              <BarPanel title="Sales by region" data={byRegion} />
              <BarPanel title="Profit by region" data={profitByRegion} color="var(--chart-2)" />
            </div>
            <Card className="glass-panel border-0">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="font-display text-sm font-semibold">
                  Region × category heatmap
                </CardTitle>
                <span className="flex items-center gap-1 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <Sparkles className="size-3" /> Sales intensity
                </span>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                      <th className="py-2 pr-4 font-medium">Region</th>
                      {grid.catNames.map((c) => (
                        <th key={c} className="py-2 pr-2 text-right font-medium">
                          {c}
                        </th>
                      ))}
                      <th className="py-2 text-right font-medium">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {grid.regionNames.map((r) => {
                      const total = grid.catNames.reduce((s, c) => s + grid.get(r, c), 0);
                      return (
                        <tr key={r}>
                          <td className="py-1.5 pr-4 font-medium text-foreground">{r}</td>
                          {grid.catNames.map((c) => {
                            const v = grid.get(r, c);
                            return (
                              <td key={c} className="py-1.5 pr-2 text-right">
                                <span
                                  className="inline-block w-full rounded-lg px-2 py-1.5 text-right tabular-nums text-foreground"
                                  style={{
                                    background: `color-mix(in oklab, var(--primary) ${Math.round(
                                      (v / maxCell) * 70,
                                    )}%, transparent)`,
                                  }}
                                >
                                  {money(v)}
                                </span>
                              </td>
                            );
                          })}
                          <td className="py-1.5 text-right font-semibold tabular-nums">
                            {money(total)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <p className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
          <Boxes className="size-3.5" /> Built from retail_sales_dashboard.pbix — 500 orders,
          measures match the report (Total Sales, Total Profit, Total Orders, Average Order Value,
          Total Customer).
        </p>
      </main>
    </div>
  );
}
