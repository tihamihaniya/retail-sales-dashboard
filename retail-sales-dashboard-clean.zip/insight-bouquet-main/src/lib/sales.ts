import raw from "@/data/sales.json";

export type SaleRow = {
  orderId: string;
  date: string;
  region: string;
  category: string;
  product: string;
  customer: string;
  quantity: number;
  sales: number;
  profit: number;
};

export const salesData = raw as SaleRow[];

export const regions = [...new Set(salesData.map((r) => r.region))].sort();
export const categories = [...new Set(salesData.map((r) => r.category))].sort();

export type Filters = {
  region: string;
  category: string;
  months: number | "all";
};

const MONTHS = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

export function applyFilters(rows: SaleRow[], f: Filters): SaleRow[] {
  let out = rows;
  if (f.region !== "all") out = out.filter((r) => r.region === f.region);
  if (f.category !== "all") out = out.filter((r) => r.category === f.category);
  if (f.months !== "all" && out.length) {
    const last = new Date(rows[rows.length - 1]!.date);
    const from = new Date(last);
    from.setMonth(from.getMonth() - f.months);
    out = out.filter((r) => new Date(r.date) >= from);
  }
  return out;
}

/** Mirrors the report's DAX measures. */
export function kpis(rows: SaleRow[]) {
  const totalSales = rows.reduce((s, r) => s + r.sales, 0);
  const totalProfit = rows.reduce((s, r) => s + r.profit, 0);
  const customers = new Set(rows.map((r) => r.customer)).size;
  return {
    totalSales,
    totalProfit,
    totalOrders: customers, // Total Orders = DISTINCTCOUNT(Customer) in the report
    totalCustomers: customers,
    avgOrderValue: customers ? totalSales / customers : 0,
    units: rows.reduce((s, r) => s + r.quantity, 0),
    margin: totalSales ? (totalProfit / totalSales) * 100 : 0,
  };
}

export function groupBy(
  rows: SaleRow[],
  key: keyof SaleRow,
  metric: "sales" | "profit" | "quantity" | "orders",
) {
  const map = new Map<string, number>();
  for (const r of rows) {
    const k = String(r[key]);
    const v = metric === "orders" ? 1 : (r[metric] as number);
    map.set(k, (map.get(k) ?? 0) + v);
  }
  return [...map.entries()]
    .map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
    .sort((a, b) => b.value - a.value);
}

export function monthlyTrend(rows: SaleRow[]) {
  const map = new Map<string, { sales: number; profit: number }>();
  for (const r of rows) {
    const k = r.date.slice(0, 7);
    const cur = map.get(k) ?? { sales: 0, profit: 0 };
    cur.sales += r.sales;
    cur.profit += r.profit;
    map.set(k, cur);
  }
  return [...map.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([k, v]) => ({
      month: `${MONTHS[Number(k.slice(5, 7)) - 1]} ${k.slice(2, 4)}`,
      sales: Math.round(v.sales),
      profit: Math.round(v.profit),
    }));
}

export function matrix(rows: SaleRow[]) {
  const regionNames = [...new Set(rows.map((r) => r.region))].sort();
  const catNames = [...new Set(rows.map((r) => r.category))].sort();
  const cells = new Map<string, number>();
  for (const r of rows)
    cells.set(`${r.region}|${r.category}`, (cells.get(`${r.region}|${r.category}`) ?? 0) + r.sales);
  return {
    regionNames,
    catNames,
    get: (region: string, cat: string) => cells.get(`${region}|${cat}`) ?? 0,
  };
}

export const money = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(n);

export const compact = (n: number) =>
  new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(n);
